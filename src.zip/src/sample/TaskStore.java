package sample;

public interface TaskStore <M extends ScheduledTask>{
	
	void add(M task);
	
	void pollCDC(M task);

}

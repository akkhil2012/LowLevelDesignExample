package sample;

import java.time.LocalTime;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class App {

	public static void main(String args[]) {

		PriorityBlockingQueueTaskStore store = new PriorityBlockingQueueTaskStore(new Comparator<ScheduledTask>() {
			
			@Override
			public int compare(ScheduledTask o1, ScheduledTask o2) {
				return o1.getExecutionTime().compareTo(o2.getExecutionTime());
			}
		});

		TaskRunner taskRunner = new TaskRunner(store);

		
		/*ExecutorService service = Executors.newFixedThreadPool(5);
		
		int i=0;
		while(i++<5) {
			service.execute(taskRunner);
		}
		*/
		
		ScheduledExecutorService service = Executors.newScheduledThreadPool(5);
		
		
		service.scheduleAtFixedRate(taskRunner, 0, 2, TimeUnit.SECONDS);
		
		
		
		
		
		//Thread t1 = new Thread(taskRunner);
		//t1.start();

	}

}

class TaskRunner implements Runnable {

	PriorityBlockingQueueTaskStore store;

	TaskRunner(PriorityBlockingQueueTaskStore store) {
		this.store = store;
	}

	@Override
	public void run() {
		LocalTime executionTime = LocalTime.now();
		executionTime.plusSeconds(3);
		ScheduledTask scheduledTask = new OneTimeTask(executionTime);
		this.store.add(scheduledTask);

	}

}

package sample;

import java.time.LocalTime;

public abstract class ScheduledTask implements Comparable<ScheduledTask>{

	LocalTime executionTime;

	public ScheduledTask(LocalTime executionTime) {
		super();
		this.executionTime = executionTime;
	}

	public LocalTime getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(LocalTime executionTime) {
		this.executionTime = executionTime;
	}

}

package sample;

import java.time.LocalTime;

public class OneTimeTask extends ScheduledTask{

	public OneTimeTask(LocalTime executionTime) {
		super(executionTime);
		System.out.print("Executuon task started for ----------> " + Thread.currentThread().getName());
	}

	@Override
	public int compareTo(ScheduledTask o) {
		// TODO Auto-generated method stub
		return 0;
	}

}

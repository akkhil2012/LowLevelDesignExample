package sample;

import java.util.Comparator;
import java.util.concurrent.PriorityBlockingQueue;

import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
org.springframework.jdbc.datasource.DriverManagerDataSource;

public class PriorityBlockingQueueTaskStore implements TaskStore<ScheduledTask> {

	private PriorityBlockingQueue<ScheduledTask> queue;

	public PriorityBlockingQueueTaskStore(Comparator<ScheduledTask> comparator) {
		super();
		this.queue = new PriorityBlockingQueue<>();
	}

	@Override
	public void add(ScheduledTask task) {
		queue.add(task);
		System.out.println(" Added task in queue for thread --> " + Thread.currentThread().getName());

	}
	
	 public DataSource dataSource() {
	        DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
	        dataSource.setUrl("jdbc:mysql://localhost:3306/your_database");
	        dataSource.setUsername("your_username");
	        dataSource.setPassword("your_password");
	        return dataSource;
	    }

	@Override
	public void pollCDC(ScheduledTask task) {
		System.out.print("pollong from DB...");
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource());
	}

}
